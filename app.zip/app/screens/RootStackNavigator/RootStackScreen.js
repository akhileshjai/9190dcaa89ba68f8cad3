/**
 * Root Stack Screen
 */
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import {
    View,
    Text,
    Image,
    ImageBackground
} from 'react-native';

import SplashScreen from '../Splash/SplashScreen';
import HomeScreen from '../Home/HomeScreen';
import COLOR_CONST from '../../../app/theme/ColorConstants';
import AsteroidListScreen from '../AsteroidList/AsteroidList';
import AsteroidDataListScreen from '../AsteroidDataList/AsteroidDataList';
import AsteroidDetailScreen from '../AsteroidDetail/AsteroidDetail';
import { verticalScale } from '../../utils/Scale';

const RootStack = createStackNavigator();
const NewStack = createStackNavigator();

function BackGroundImage() {
    return (
        <ImageBackground
            style={{ width: 50, height: 50, marginLeft: verticalScale(90) }}
            source={require('../../assets/images/asteroid_details.jpg')}>
        </ImageBackground>
    );
}

const RootStackScreen = (props) => {
    return (
        <RootStack.Navigator>
            <RootStack.Screen options={{ headerShown: false }} name="SplashScreen" component={SplashScreen} />
            <RootStack.Screen
                options={({ route, navigation }) => ({
                    title: 'Home',
                    headerTitleAlign: 'center',
                    headerTintColor: 'white',
                    headerStyle: { backgroundColor: 'black' },
                    headerTitleStyle: { textAlign: 'center', alignSelf: 'center' },
                    route: { route },
                    navigation: { navigation }
                })
                }
                name="HomeScreen"
                component={HomeScreen}
            />
            <RootStack.Screen
                options={({ route, navigation }) => ({
                    title: 'Asteroid List',
                    headerTitleAlign: 'center',
                    headerTintColor: 'white',
                    headerStyle: { backgroundColor: "black" },
                    headerTitleStyle: { textAlign: 'center', alignSelf: 'center' },
                    route: { route },
                    navigation: { navigation }
                })
                }
                name="AsteroidListScreen"
                component={AsteroidListScreen}
            />
            <RootStack.Screen
                options={({ route, navigation }) => ({
                    title: 'Asteroid Data List',
                    headerTitleAlign: 'center',
                    headerTintColor: 'white',
                    headerStyle: { backgroundColor: "black" },
                    headerTitleStyle: { textAlign: 'center', alignSelf: 'center' },
                    route: { route },
                    navigation: { navigation }
                })
                }
                name="AsteroidDataListScreen"
                component={AsteroidDataListScreen}
            />
            <RootStack.Screen
                options={({ route, navigation }) => ({
                    title: 'Asteroid Detail',
                    headerBackground: () => (
                        <Image
                            style={{ width: 410, height: 65 }}
                            source={require('../../assets/images/asteroidHeader.jpg')} />
                    ),
                    headerTitleAlign: 'center',
                    headerTintColor: 'Black',
                    headerTitleStyle: { textAlign: 'center', alignSelf: 'center' },
                    route: { route },
                    navigation: { navigation }
                })
                }
                name="AsteroidDetailScreen"
                component={AsteroidDetailScreen}
            />
        </RootStack.Navigator>
    );
};

export default RootStackScreen;