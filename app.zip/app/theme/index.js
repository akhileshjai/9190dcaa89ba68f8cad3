/**
 * TestProject
 */

import Colors from './Colors';
import ApplicationStyles from './ApplicationStyles';

export { Colors, ApplicationStyles }
