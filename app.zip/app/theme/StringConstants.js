//*> OnBoarding 

export const CONNECTING = 'Connecting';
