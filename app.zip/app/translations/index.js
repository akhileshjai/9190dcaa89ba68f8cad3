import en from './en.json';
import fr from './fr.json';

const translatedLanguages = {
    en, fr
}
export default translatedLanguages;