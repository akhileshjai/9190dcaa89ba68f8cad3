export const Config = {
    API_URL: 'https://jsonplaceholder.typicode.com/users/',
  }