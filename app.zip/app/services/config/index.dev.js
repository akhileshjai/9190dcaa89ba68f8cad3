export const Config = {
    API_URL: 'http://api.blackandwhiteenglish.com/v1/',
  }