export default config = {
  baseUrl: 'https://jsonplaceholder.typicode.com/users/',
}